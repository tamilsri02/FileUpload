package com.cognizant.rabobank.display.model;

public class Issues {

	private String firstName;
	private String surName;
	private String issueCount;
	private String dateOfBirth;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getSurName() {
		return surName;
	}

	public void setSurName(String surName) {
		this.surName = surName;
	}

	public String getIssueCount() {
		return issueCount;
	}

	public void setIssueCount(String issueCount) {
		this.issueCount = issueCount;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	@Override
	public String toString() {
		return "Issues [firstName=" + firstName + ", surName=" + surName + ", issueCount=" + issueCount
				+ ", dateOfBirth=" + dateOfBirth + "]";
	}
}
