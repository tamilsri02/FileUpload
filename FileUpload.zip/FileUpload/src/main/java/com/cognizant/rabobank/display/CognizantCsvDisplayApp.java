package com.cognizant.rabobank.display;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.cognizant.rabobank.display.property.FileStorageProperties;

@SpringBootApplication
@EnableConfigurationProperties({
		FileStorageProperties.class
})
public class CognizantCsvDisplayApp {

	public static void main(String[] args) {
		SpringApplication.run(CognizantCsvDisplayApp.class, args);
	}
}
