package com.cognizant.rabobank.display.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.cognizant.rabobank.display.model.Issues;
import com.cognizant.rabobank.display.service.FileStorageService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
public class CtsCsvController {

	private static final Logger logger = LoggerFactory.getLogger(CtsCsvController.class);

	@Autowired
	private FileStorageService fileStorageService;

	Map<Long, Issues> recStores = new HashMap<Long, Issues>();
	
	@RequestMapping(value = "/uploadFile", method = { RequestMethod.POST })
	@ResponseBody
	public String uploadFile(@RequestParam("file") MultipartFile file) {

		logger.info("");
		logger.info("**************************************************");
		logger.info("POST /uploadFile");
		logger.info(" fileName: " + file.getOriginalFilename());
		logger.info("**************************************************");
		logger.info("");

		recStores = fileStorageService.processFile(file);
		return "displayIssues.html";
	}

	@RequestMapping(value = "/displayIssues", method = { RequestMethod.GET })
	@ResponseBody
	public List<Issues> getResource() {

		logger.info("");
		logger.info("**************************************************");
		logger.info("GET /displayIssues");
		logger.info("Loading data in external page: /displayIssues");
		logger.info(" fileData: " + recStores);
		logger.info("*****************************************");

		List<Issues> recList = recStores.entrySet().stream().map(entry -> entry.getValue())
				.collect(Collectors.toList());
		return recList;
	}
}
