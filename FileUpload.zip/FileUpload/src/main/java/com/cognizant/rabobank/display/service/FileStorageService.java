package com.cognizant.rabobank.display.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.cognizant.rabobank.display.controller.CtsCsvController;
import com.cognizant.rabobank.display.exception.FileStorageException;
import com.cognizant.rabobank.display.exception.MyFileNotFoundException;
import com.cognizant.rabobank.display.model.Issues;
import com.cognizant.rabobank.display.property.FileStorageProperties;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FileStorageService {

	private static final Logger logger = LoggerFactory.getLogger(CtsCsvController.class);

    private final Path fileStorageLocation;

    @Autowired
    public FileStorageService(FileStorageProperties fileStorageProperties) {
        this.fileStorageLocation = Paths.get(fileStorageProperties.getUploadDir())
                .toAbsolutePath().normalize();

        try {
            Files.createDirectories(this.fileStorageLocation);
        } catch (Exception ex) {
            throw new FileStorageException("Could not create the directory where the uploaded files will be stored.", ex);
        }
    }

    public Map<Long, Issues> processFile(MultipartFile file) {
        // Normalize file name
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        Map<Long, Issues> recStores = new HashMap<Long, Issues>();

        try {
            // Check if the file's name contains invalid characters
            if(fileName.contains("..")) {
            	logger.error("Sorry! Filename contains invalid path sequence " + fileName);
                throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
            }

    		BufferedReader fileReader = null;

    		final String DELIMITER = ",";
    		String line = "";
    		InputStream is = file.getInputStream();
    		fileReader = new BufferedReader(new InputStreamReader(is));
    		fileReader.readLine();
    		int i = 0;
    		List<Issues> issues = new ArrayList<Issues>();
    		while ((line = fileReader.readLine()) != null) {
    			String[] fieldValues = line.split(DELIMITER);
    			Issues newLine = new Issues();
    			newLine.setFirstName(fieldValues[0]);
    			newLine.setSurName(fieldValues[1]);
    			newLine.setIssueCount(fieldValues[2]);
    			newLine.setDateOfBirth(fieldValues[3]);
    			issues.add(newLine);
    			recStores.put(Long.valueOf(++i), newLine);
    		}
    		fileReader.close();

            return recStores;
            
        } catch (IOException ex) {
        	logger.error("Could not store file " + fileName + ". Please try again!", ex);
            throw new FileStorageException("Could not store file " + fileName + ". Please try again!", ex);
        }
    }

    public Resource loadFileAsResource(String fileName) {
        try {
            Path filePath = this.fileStorageLocation.resolve(fileName).normalize();
            Resource resource = new UrlResource(filePath.toUri());
            if(resource.exists()) {
                return resource;
            } else {
            	logger.error("File not found " + fileName);
                throw new MyFileNotFoundException("File not found " + fileName);
            }
        } catch (MalformedURLException ex) {
        	logger.error("File not found " + fileName, ex);
            throw new MyFileNotFoundException("File not found " + fileName, ex);
        }
    }
}
