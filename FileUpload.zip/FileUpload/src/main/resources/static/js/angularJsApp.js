var app = angular.module('app', []);

//#######################
//JSA CONTROLLER
//#######################

app.controller('jsaController', function($scope, $http, $location) {
	$scope.listCustomers = [];
	
	// $scope.getAllCustomer = 
	function getAllRecord(){
		// get URL
		var url = "http://localhost:8080" + "/displayIssues";
		// do getting
		$http.get(url).then(function (response) {
			$scope.getDivAvailable = true;
			$scope.listCustomers = response.data;
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " +  response.statusText;
		});
	}
	getAllRecord();
});